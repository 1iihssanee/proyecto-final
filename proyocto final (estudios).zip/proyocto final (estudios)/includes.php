<?php

$mysqli = new mysqli("localhost", "milsoluciones", "milsoluciones1234", "milsoluciones");

if($mysqli->connect_errno) {
    echo "No se puede connectar ala base de datos";
}

return $mysqli;

?>