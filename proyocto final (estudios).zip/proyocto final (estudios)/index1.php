<?php
session_start();
if(isset($_SESSION['logueado']) && $_SESSION['logueado'] == TRUE) {
    header("Location: home.php");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <title>milsoluciones</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilos.css" type="text/css">
</head>

<body>

<div id="wrapper">

    <div class="w-left"><img src="img/ordenador.png"></div>

    <div class="w-right">

        <?php
        if(isset($_GET['error'])) {
            echo "<p style='color:red'>Error el usuario o contraseña no coinciden intenta de nuevo</p>";
        }

        ?>

        <?php
        if(isset($_POST['entrar'])) {

            require("includes.php");

            $username = $mysqli->real_escape_string($_POST['usuario']);
            $password = md5($_POST['password']);

            $consulta = "SELECT username,password FROM users WHERE username = '$username' AND password = '$password'";

            if($resultado = $mysqli->query($consulta)) {
                while($row = $resultado->fetch_array()) {

                    $userok = $row['username'];
                    $passok = $row['password'];
                    $id = $row['id'];

                }
                $resultado->close();
            }
            $mysqli->close();


            if(isset($username) && isset($password)) {

                if($username == $userok && $password == $passok) {

                    session_start();
                    $_SESSION['logueado'] = TRUE;
                    $_SESSION['username'] = $userok;
                    $_SESSION['id'] = $id;
                    header("Location: home.php");

                }

                else {

                    Header("Location: index1.php?error=login");

                }

            }


        }
        ?>

        <div class="main-content">
            <div class="header">
                <h1>Milsoluciones</h1>
            </div>
            <div class="l-part">
                <form action="" method="post">
                    <input type="text" placeholder="Usuario" class="input" name="usuario" />
                    <div class="overlap-text">
                        <input type="password" placeholder="Contraseña" class="input" name="password" />
                        <a href="olvidar.php">Olvidaste?</a>
                    </div>
                    <input type="submit" value="Entrar" class="btn" name="entrar" />
                </form>
            </div>
        </div>

        <div class="sub-content">
            <div class="s-part">
                ¿No tienes una cuenta? <a href="registro.php">Regístrate</a>
            </div>
        </div>

        <p><img src=""></p>

    </div>

</div>

</body>
</html>