CREATE DATABASE milsoluciones;
create user milsoluciones@localhost IDENTIFIED by 'milsoluciones1234';
grant all on milsoluciones .*to milsoluciones@localhost;
use milsoluciones;


CREATE TABLE `users` (
  `id` int(20) NOT NULL,
  `username` text NOT NULL,
  `password` varchar(40) NOT NULL,
  `email` text  NOT NULL,
  `name` text ,
  `phone` text ,
  `birthday` date DEFAULT NULL,
  `sex` enum('male','female') DEFAULT NULL,
  `bio` text,
  `site_language` int(20) UNSIGNED DEFAULT '1',
  `avatar` varchar(225)  NOT NULL DEFAULT 'default.png',
  `private_profile` enum('0','1')  NOT NULL DEFAULT '0' COMMENT 'Este perfil es privado?',
  `verified` enum('0','1')NOT NULL DEFAULT '0' COMMENT 'Este perfil esta verificado?',
  `banned` enum('0','1')  NOT NULL DEFAULT '0' COMMENT 'Este perfil esta baneado?',
  `code` varchar(40)  NOT NULL,
  `token` varchar(255)  NOT NULL,
  `confirmed` enum('0','1')  NOT NULL DEFAULT '0' COMMENT 'Verifico el correo',
  `signup_date` datetime NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `signup_ip` varchar(100)  DEFAULT NULL,
  `last_ip` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ;