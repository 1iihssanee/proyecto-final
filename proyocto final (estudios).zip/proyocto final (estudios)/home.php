<?php
session_start();
if(!isset($_SESSION['logueado']) && $_SESSION['logueado'] == FALSE) {
    header("Location: index1.php");
}

?>



<?php
require("includes.php");

$consultaA = "SELECT confirmed FROM users WHERE username = '".$_SESSION['username']."'";
$resultadoA = $mysqli->query($consultaA);
$row = $resultadoA->fetch_array();

if($row['confirmed'] == 0) {
    echo "<div class='topbarc'> Confirma tu email<a href='code.php'> aquí </a></div>";
}

$mysqli->close();
?>



<?php
echo $_SESSION['username'];

?>
<br>
<a href="logout.php">salir</a>


